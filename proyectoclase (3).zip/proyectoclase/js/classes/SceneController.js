class SceneController {
    constructor(canvasId) {
        // Verificar que THREE está disponible
        if (typeof THREE === 'undefined') {
            console.error('❌ THREE no está definido. Asegúrate de que Three.js se cargó antes de SceneController.');
            throw new Error('THREE is not defined. Three.js library is required.');
        }

        this.canvas = document.getElementById(canvasId);
        if (!this.canvas) {
            console.error(`❌ Canvas con id "${canvasId}" no encontrado`);
            throw new Error(`Canvas element with id "${canvasId}" not found`);
        }

        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.currentPlanet = null;
        this.planetMesh = null;
        this.animationId = null;
        this.clock = new THREE.Clock();
        this.lastTime = 0;
        this.fps = 0;
        
        this.initScene();
        this.animate();
    }

    initScene() {
        try {
            // Asegurarse de que el canvas tenga dimensiones
            const width = this.canvas.clientWidth || this.canvas.parentElement.clientWidth || 800;
            const height = this.canvas.clientHeight || this.canvas.parentElement.clientHeight || 600;

            console.log('📐 Dimensiones del canvas:', width, 'x', height);

            // Scene
            this.scene = new THREE.Scene();
            this.scene.background = new THREE.Color(0x000510);
            this.scene.fog = new THREE.Fog(0x000510, 10, 50);

            // Camera
            this.camera = new THREE.PerspectiveCamera(
                60,
                width / height,
                0.1,
                1000
            );
            this.camera.position.set(0, 2, 5);
            this.camera.lookAt(0, 0, 0);

            // Renderer
            this.renderer = new THREE.WebGLRenderer({ 
                canvas: this.canvas, 
                antialias: true,
                alpha: false 
            });
            this.renderer.setSize(width, height);
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            this.renderer.shadowMap.enabled = true;
            this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
            this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
            this.renderer.toneMappingExposure = 1.0;

            // Controls
            if (typeof THREE.OrbitControls !== 'undefined') {
                this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
                this.controls.enableDamping = true;
                this.controls.dampingFactor = 0.05;
                this.controls.minDistance = 2;
                this.controls.maxDistance = 20;
                this.controls.maxPolarAngle = Math.PI / 1.5;
                console.log('✅ OrbitControls inicializados');
            } else {
                console.warn('⚠️ OrbitControls no disponible - usando controles básicos');
            }

            // Lights
            this.setupLights();

            // Stars background
            this.createStarfield();

            // Event listeners
            window.addEventListener('resize', () => this.updateSize());

            console.log('✅ Escena 3D inicializada correctamente');

        } catch (error) {
            console.error('❌ Error al inicializar escena 3D:', error);
            throw error;
        }
    }

    setupLights() {
        // Ambient light
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.3);
        this.scene.add(ambientLight);

        // Main directional light (Sol)
        const mainLight = new THREE.DirectionalLight(0xffffff, 1.2);
        mainLight.position.set(10, 10, 5);
        mainLight.castShadow = true;
        mainLight.shadow.mapSize.width = 2048;
        mainLight.shadow.mapSize.height = 2048;
        mainLight.shadow.camera.near = 0.5;
        mainLight.shadow.camera.far = 50;
        this.scene.add(mainLight);

        // Fill lights
        const fillLight1 = new THREE.PointLight(0x4488ff, 0.5, 50);
        fillLight1.position.set(-10, 5, 10);
        this.scene.add(fillLight1);

        const fillLight2 = new THREE.PointLight(0xff8844, 0.3, 50);
        fillLight2.position.set(10, 5, -10);
        this.scene.add(fillLight2);

        // Ground plane for shadows
        const groundGeometry = new THREE.PlaneGeometry(100, 100);
        const groundMaterial = new THREE.ShadowMaterial({ opacity: 0.3 });
        const ground = new THREE.Mesh(groundGeometry, groundMaterial);
        ground.rotation.x = -Math.PI / 2;
        ground.position.y = -2;
        ground.receiveShadow = true;
        this.scene.add(ground);

        console.log('✅ Luces configuradas');
    }

    createStarfield() {
        const starsGeometry = new THREE.BufferGeometry();
        const starsMaterial = new THREE.PointsMaterial({
            color: 0xffffff,
            size: 0.7,
            transparent: true,
            opacity: 0.8
        });

        const starsVertices = [];
        for (let i = 0; i < 10000; i++) {
            const x = (Math.random() - 0.5) * 2000;
            const y = (Math.random() - 0.5) * 2000;
            const z = (Math.random() - 0.5) * 2000;
            starsVertices.push(x, y, z);
        }

        starsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starsVertices, 3));
        const stars = new THREE.Points(starsGeometry, starsMaterial);
        this.scene.add(stars);

        console.log('✅ Campo de estrellas creado');
    }

    loadPlanet(planetKey) {
        try {
            const planetData = PlanetData.getPlanet(planetKey);
            this.currentPlanet = planetData;

            // Remove previous planet
            if (this.planetMesh) {
                this.scene.remove(this.planetMesh);
                this.planetMesh.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) {
                        if (Array.isArray(obj.material)) {
                            obj.material.forEach(mat => mat.dispose());
                        } else {
                            obj.material.dispose();
                        }
                    }
                });
            }

            // Create new planet
            this.planetMesh = this.createPlanet(planetData);
            this.scene.add(this.planetMesh);

            // Update info overlay
            this.updateInfo(planetData);

            // Reset camera
            this.resetCamera();

            console.log('🪐 Planeta cargado:', planetData.name);
        } catch (error) {
            console.error('❌ Error al cargar planeta:', error);
        }
    }

    createPlanet(data) {
        const group = new THREE.Group();

        // Planet sphere
        const geometry = new THREE.SphereGeometry(data.size, 64, 64);
        const material = new THREE.MeshStandardMaterial({
            color: data.color,
            roughness: 0.7,
            metalness: 0.1,
            emissive: data.color,
            emissiveIntensity: 0.1
        });

        const planet = new THREE.Mesh(geometry, material);
        planet.castShadow = true;
        planet.receiveShadow = true;
        group.add(planet);

        // Add atmosphere for some planets
        if (['tierra', 'venus', 'marte'].includes(data.name.toLowerCase())) {
            const atmosphereGeometry = new THREE.SphereGeometry(data.size * 1.05, 64, 64);
            const atmosphereMaterial = new THREE.MeshStandardMaterial({
                color: data.color,
                transparent: true,
                opacity: 0.2,
                side: THREE.BackSide
            });
            const atmosphere = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
            group.add(atmosphere);
        }

        // Add rings for Saturn
        if (data.name === 'Saturno') {
            const ringGeometry = new THREE.RingGeometry(data.size * 1.5, data.size * 2.5, 64);
            const ringMaterial = new THREE.MeshStandardMaterial({
                color: 0xe6d3a8,
                side: THREE.DoubleSide,
                transparent: true,
                opacity: 0.7
            });
            const rings = new THREE.Mesh(ringGeometry, ringMaterial);
            rings.rotation.x = Math.PI / 2.5;
            group.add(rings);
        }

        // Animation data
        group.userData.rotationSpeed = 0.001 + Math.random() * 0.002;

        return group;
    }

    updateInfo(planetData) {
        const nameEl = document.getElementById('planetName');
        const infoEl = document.getElementById('planetInfo');
        
        if (nameEl) {
            nameEl.textContent = `${planetData.emoji} ${planetData.name}`;
        }
        
        if (infoEl) {
            infoEl.innerHTML = `
                <p><strong>Diámetro:</strong> ${planetData.diameter}</p>
                <p><strong>Distancia al Sol:</strong> ${planetData.distance}</p>
                <p><strong>Periodo orbital:</strong> ${planetData.period}</p>
                <p><strong>Lunas:</strong> ${planetData.moons}</p>
                <p style="margin-top: 10px; color: #b8c9e8;">${planetData.description}</p>
            `;
        }
    }

    resetCamera() {
        if (this.controls) {
            this.controls.target.set(0, 0, 0);
        }
        this.camera.position.set(0, 2, 5);
        this.camera.lookAt(0, 0, 0);
        if (this.controls) {
            this.controls.update();
        }
    }

    zoomIn() {
        const factor = 0.9;
        this.camera.position.multiplyScalar(factor);
        if (this.controls) {
            this.controls.update();
        }
    }

    zoomOut() {
        const factor = 1.1;
        this.camera.position.multiplyScalar(factor);
        if (this.controls) {
            this.controls.update();
        }
    }

    rotateLeft() {
        if (this.controls && THREE.MathUtils) {
            this.controls.rotateLeft(THREE.MathUtils.degToRad(15));
            this.controls.update();
        }
    }

    rotateRight() {
        if (this.controls && THREE.MathUtils) {
            this.controls.rotateLeft(THREE.MathUtils.degToRad(-15));
            this.controls.update();
        }
    }

    toggleRotation() {
        if (this.controls) {
            this.controls.autoRotate = !this.controls.autoRotate;
            this.controls.autoRotateSpeed = 0.5;
        }
    }

    updateSize() {
        if (!this.camera || !this.renderer || !this.canvas) return;

        const width = this.canvas.clientWidth || this.canvas.parentElement.clientWidth || 800;
        const height = this.canvas.clientHeight || this.canvas.parentElement.clientHeight || 600;

        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();

        this.renderer.setSize(width, height);
    }

    animate() {
        this.animationId = requestAnimationFrame(() => this.animate());

        // Update controls
        if (this.controls) {
            this.controls.update();
        }

        // Rotate planet
        if (this.planetMesh && this.planetMesh.userData) {
            this.planetMesh.rotation.y += this.planetMesh.userData.rotationSpeed || 0.001;
        }

        // Render
        if (this.renderer && this.scene && this.camera) {
            this.renderer.render(this.scene, this.camera);
        }

        // Update FPS
        this.updateFPS();
    }

    updateFPS() {
        const now = performance.now();
        const delta = now - this.lastTime;
        
        if (delta > 0) {
            this.fps = Math.round(1000 / delta);
            const fpsCounter = document.getElementById('fpsCounter');
            if (fpsCounter) {
                fpsCounter.textContent = `FPS: ${this.fps}`;
            }
        }
        
        this.lastTime = now;
    }

    dispose() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
        if (this.renderer) {
            this.renderer.dispose();
        }
    }
}