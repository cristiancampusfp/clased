class PlanetData {
    static planets = {
        mercury: {
            name: 'Mercurio',
            emoji: '☿️',
            diameter: '4,879 km',
            distance: '57.9 millones km',
            period: '88 días',
            moons: '0',
            color: 0x8c7853,
            size: 0.4,
            description: 'El planeta más cercano al Sol y el más pequeño del sistema solar.'
        },
        venus: {
            name: 'Venus',
            emoji: '♀️',
            diameter: '12,104 km',
            distance: '108.2 millones km',
            period: '225 días',
            moons: '0',
            color: 0xffc649,
            size: 0.95,
            description: 'El planeta más caliente del sistema solar con una atmósfera densa.'
        },
        earth: {
            name: 'Tierra',
            emoji: '🌍',
            diameter: '12,742 km',
            distance: '149.6 millones km',
            period: '365.25 días',
            moons: '1 (Luna)',
            color: 0x2244ff,
            size: 1.0,
            description: 'Nuestro hogar, el único planeta conocido con vida.'
        },
        mars: {
            name: 'Marte',
            emoji: '♂️',
            diameter: '6,779 km',
            distance: '227.9 millones km',
            period: '687 días',
            moons: '2 (Fobos, Deimos)',
            color: 0xcd5c5c,
            size: 0.53,
            description: 'El planeta rojo, objetivo de futuras misiones tripuladas.'
        },
        jupiter: {
            name: 'Júpiter',
            emoji: '♃',
            diameter: '139,820 km',
            distance: '778.5 millones km',
            period: '11.9 años',
            moons: '95+',
            color: 0xc88b3a,
            size: 2.5,
            description: 'El planeta más grande del sistema solar, un gigante gaseoso.'
        },
        saturn: {
            name: 'Saturno',
            emoji: '♄',
            diameter: '116,460 km',
            distance: '1.43 mil millones km',
            period: '29.5 años',
            moons: '146+',
            color: 0xfad5a5,
            size: 2.1,
            description: 'Famoso por sus espectaculares anillos.'
        },
        uranus: {
            name: 'Urano',
            emoji: '♅',
            diameter: '50,724 km',
            distance: '2.87 mil millones km',
            period: '84 años',
            moons: '27',
            color: 0x4fd0e7,
            size: 1.6,
            description: 'Un gigante helado que rota de lado.'
        },
        neptune: {
            name: 'Neptuno',
            emoji: '♆',
            diameter: '49,244 km',
            distance: '4.50 mil millones km',
            period: '165 años',
            moons: '14',
            color: 0x4166f5,
            size: 1.5,
            description: 'El planeta más lejano, con los vientos más fuertes del sistema solar.'
        }
    };

    static getPlanet(key) {
        return this.planets[key] || this.planets.earth;
    }

    static getAllPlanets() {
        return this.planets;
    }
}