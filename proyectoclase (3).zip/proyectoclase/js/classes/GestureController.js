class GestureController {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.canvas.width = 320;
        this.canvas.height = 180;
        
        this.isActive = false;
        this.hands = null;
        this.camera = null;
        this.video = null;
        this.onGestureCallback = null;
        this.lastGestureTime = 0;
        this.gestureCooldown = 500; // ms
    }

    async initialize() {
        if (this.isActive) {
            console.log('Gestos ya están activos');
            return;
        }

        try {
            // Crear elemento de video
            this.video = document.createElement('video');
            this.video.style.display = 'none';
            document.body.appendChild(this.video);

            // Solicitar acceso a cámara
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { width: 640, height: 480 }
            });

            this.video.srcObject = stream;
            await this.video.play();

            // Inicializar MediaPipe Hands
            this.hands = new window.Hands({
                locateFile: (file) => {
                    return `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`;
                }
            });

            this.hands.setOptions({
                maxNumHands: 1,
                modelComplexity: 1,
                minDetectionConfidence: 0.5,
                minTrackingConfidence: 0.5
            });

            this.hands.onResults((results) => this.onResults(results));

            // Iniciar procesamiento
            this.camera = new window.Camera(this.video, {
                onFrame: async () => {
                    await this.hands.send({ image: this.video });
                },
                width: 640,
                height: 480
            });

            this.camera.start();

            this.isActive = true;
            this.updateUI(true);
            console.log('✋ Detección de gestos iniciada');

        } catch (error) {
            console.error('Error al iniciar gestos:', error);
            alert('No se pudo acceder a la cámara. Por favor, permite el acceso.');
        }
    }

    onResults(results) {
        // Limpiar canvas
        this.ctx.save();
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Dibujar video de fondo
        if (results.image) {
            this.ctx.drawImage(results.image, 0, 0, this.canvas.width, this.canvas.height);
        }

        // Dibujar landmarks
        if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
            for (const landmarks of results.multiHandLandmarks) {
                this.drawLandmarks(landmarks);
                this.detectGesture(landmarks);
            }
        }

        this.ctx.restore();
    }

    drawLandmarks(landmarks) {
        // Dibujar conexiones
        const connections = [
            [0, 1], [1, 2], [2, 3], [3, 4],  // Pulgar
            [0, 5], [5, 6], [6, 7], [7, 8],  // Índice
            [5, 9], [9, 10], [10, 11], [11, 12],  // Medio
            [9, 13], [13, 14], [14, 15], [15, 16],  // Anular
            [13, 17], [17, 18], [18, 19], [19, 20],  // Meñique
            [0, 17]
        ];

        this.ctx.strokeStyle = '#00FF00';
        this.ctx.lineWidth = 2;

        for (const [start, end] of connections) {
            const startPoint = landmarks[start];
            const endPoint = landmarks[end];
            
            this.ctx.beginPath();
            this.ctx.moveTo(startPoint.x * this.canvas.width, startPoint.y * this.canvas.height);
            this.ctx.lineTo(endPoint.x * this.canvas.width, endPoint.y * this.canvas.height);
            this.ctx.stroke();
        }

        // Dibujar puntos
        this.ctx.fillStyle = '#FF0000';
        for (const landmark of landmarks) {
            this.ctx.beginPath();
            this.ctx.arc(
                landmark.x * this.canvas.width,
                landmark.y * this.canvas.height,
                3, 0, 2 * Math.PI
            );
            this.ctx.fill();
        }
    }

    detectGesture(landmarks) {
        const now = performance.now();
        if (now - this.lastGestureTime < this.gestureCooldown) return;

        const gesture = this.recognizeGesture(landmarks);
        
        if (gesture && this.onGestureCallback) {
            this.onGestureCallback(gesture);
            this.showGestureFeedback(gesture);
            this.lastGestureTime = now;
        }
    }

    recognizeGesture(landmarks) {
        const thumbTip = landmarks[4];
        const indexTip = landmarks[8];
        const middleTip = landmarks[12];
        const ringTip = landmarks[16];
        const pinkyTip = landmarks[20];
        const wrist = landmarks[0];

        // Calcular distancias
        const distance = (p1, p2) => {
            const dx = p1.x - p2.x;
            const dy = p1.y - p2.y;
            return Math.sqrt(dx * dx + dy * dy);
        };

        // Puño cerrado (todas las puntas cerca de la palma)
        const fistThreshold = 0.15;
        const isFist = distance(indexTip, wrist) < fistThreshold &&
                       distance(middleTip, wrist) < fistThreshold &&
                       distance(ringTip, wrist) < fistThreshold &&
                       distance(pinkyTip, wrist) < fistThreshold;

        if (isFist) {
            return 'pause';
        }

        // Mano abierta (todos los dedos extendidos)
        const openHandThreshold = 0.25;
        const isOpenHand = distance(indexTip, wrist) > openHandThreshold &&
                          distance(middleTip, wrist) > openHandThreshold &&
                          distance(ringTip, wrist) > openHandThreshold &&
                          distance(pinkyTip, wrist) > openHandThreshold;

        if (isOpenHand) {
            return 'select';
        }

        // Dedo índice arriba (zoom in)
        const isPointingUp = indexTip.y < wrist.y - 0.15 &&
                            middleTip.y > indexTip.y &&
                            ringTip.y > indexTip.y &&
                            pinkyTip.y > indexTip.y;

        if (isPointingUp) {
            return 'zoom_in';
        }

        // Dedo índice abajo (zoom out)
        const isPointingDown = indexTip.y > wrist.y + 0.15 &&
                              middleTip.y < indexTip.y &&
                              ringTip.y < indexTip.y &&
                              pinkyTip.y < indexTip.y;

        if (isPointingDown) {
            return 'zoom_out';
        }

        // Movimiento horizontal (rotar)
        const horizontalMovement = indexTip.x - wrist.x;
        if (Math.abs(horizontalMovement) > 0.2) {
            return horizontalMovement > 0 ? 'rotate_right' : 'rotate_left';
        }

        return null;
    }

    showGestureFeedback(gesture) {
        const feedback = document.getElementById('gestureFeedback');
        const messages = {
            'pause': '✊ Pausado',
            'select': '✋ Seleccionado',
            'zoom_in': '👆 Acercando',
            'zoom_out': '👇 Alejando',
            'rotate_left': '👈 Rotando izquierda',
            'rotate_right': '👉 Rotando derecha'
        };

        feedback.textContent = messages[gesture] || gesture;
        feedback.classList.add('show');

        setTimeout(() => {
            feedback.classList.remove('show');
        }, 1500);
    }

    stop() {
        if (this.camera) {
            this.camera.stop();
        }

        if (this.video && this.video.srcObject) {
            const tracks = this.video.srcObject.getTracks();
            tracks.forEach(track => track.stop());
            this.video.remove();
        }

        this.isActive = false;
        this.updateUI(false);
        console.log('✋ Detección de gestos detenida');
    }

    toggle() {
        if (this.isActive) {
            this.stop();
        } else {
            this.initialize();
        }
    }

    setOnGesture(callback) {
        this.onGestureCallback = callback;
    }

    updateUI(active) {
        const status = document.getElementById('gestureStatus');
        const button = document.getElementById('toggleGestures');

        if (active) {
            status.classList.add('active');
            status.querySelector('.text').textContent = 'Gestos: ON';
            button.classList.add('active');
            button.innerHTML = '<span class="icon">✋</span> Desactivar Gestos';
        } else {
            status.classList.remove('active');
            status.querySelector('.text').textContent = 'Gestos: OFF';
            button.classList.remove('active');
            button.innerHTML = '<span class="icon">✋</span> Activar Gestos';
        }
    }
}