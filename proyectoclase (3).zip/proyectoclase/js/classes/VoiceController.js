class VoiceController {
    constructor() {
        this.recognition = null;
        this.isActive = false;
        this.language = 'es-ES';
        this.onCommandCallback = null;
        this.initSpeechRecognition();
    }

    initSpeechRecognition() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        
        if (!SpeechRecognition) {
            console.error('Speech Recognition no disponible');
            return;
        }

        this.recognition = new SpeechRecognition();
        this.recognition.lang = this.language;
        this.recognition.continuous = true;
        this.recognition.interimResults = false;
        this.recognition.maxAlternatives = 1;

        this.recognition.onstart = () => {
            this.isActive = true;
            this.updateUI(true);
            console.log('🎤 Reconocimiento de voz iniciado');
        };

        this.recognition.onend = () => {
            this.isActive = false;
            this.updateUI(false);
            console.log('🎤 Reconocimiento de voz detenido');
        };

        this.recognition.onerror = (event) => {
            console.error('Error de voz:', event.error);
            if (event.error === 'not-allowed') {
                alert('Por favor, permite el acceso al micrófono');
            }
        };

        this.recognition.onresult = (event) => {
            for (let i = event.resultIndex; i < event.results.length; i++) {
                if (event.results[i].isFinal) {
                    const transcript = event.results[i][0].transcript.trim().toLowerCase();
                    this.processCommand(transcript);
                }
            }
        };
    }

    processCommand(command) {
        console.log('🎤 Comando recibido:', command);
        this.showTranscript(command);

        const commands = {
            // Planetas
            'mercurio': 'mercury',
            'venus': 'venus',
            'tierra': 'earth',
            'marte': 'mars',
            'júpiter': 'jupiter',
            'jupiter': 'jupiter',
            'saturno': 'saturn',
            'urano': 'uranus',
            'neptuno': 'neptune',
            
            // Acciones
            'acercar': 'zoom_in',
            'alejar': 'zoom_out',
            'rotar': 'rotate',
            'pausar': 'pause',
            'información': 'info',
            'info': 'info',
            'realidad aumentada': 'ar',
            'modo ar': 'ar',
            'ar': 'ar'
        };

        let recognized = false;
        
        for (const [keyword, action] of Object.entries(commands)) {
            if (command.includes(keyword)) {
                if (this.onCommandCallback) {
                    this.onCommandCallback(action);
                }
                this.speak(`Comando ${keyword} ejecutado`);
                recognized = true;
                break;
            }
        }

        if (!recognized) {
            this.speak('Comando no reconocido');
        }
    }

    speak(text) {
        if (!('speechSynthesis' in window)) return;
        
        speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = this.language;
        utterance.rate = 0.9;
        utterance.pitch = 1.0;
        speechSynthesis.speak(utterance);
    }

    showTranscript(text) {
        const transcript = document.getElementById('voiceTranscript');
        transcript.textContent = `"${text}"`;
        transcript.classList.add('show');
        
        setTimeout(() => {
            transcript.classList.remove('show');
        }, 3000);
    }

    toggle() {
        if (this.isActive) {
            this.stop();
        } else {
            this.start();
        }
    }

    start() {
        if (this.recognition) {
            try {
                this.recognition.start();
            } catch (e) {
                console.error('Error al iniciar reconocimiento:', e);
            }
        }
    }

    stop() {
        if (this.recognition) {
            this.recognition.stop();
        }
    }

    setLanguage(lang) {
        this.language = lang;
        if (this.recognition) {
            this.recognition.lang = lang;
        }
    }

    setOnCommand(callback) {
        this.onCommandCallback = callback;
    }

    updateUI(active) {
        const status = document.getElementById('voiceStatus');
        const button = document.getElementById('toggleVoice');
        
        if (active) {
            status.classList.add('active');
            status.querySelector('.text').textContent = 'Voz: ON';
            button.classList.add('active');
            button.innerHTML = '<span class="icon">🎤</span> Desactivar Voz';
        } else {
            status.classList.remove('active');
            status.querySelector('.text').textContent = 'Voz: OFF';
            button.classList.remove('active');
            button.innerHTML = '<span class="icon">🎤</span> Activar Voz';
        }
    }
}