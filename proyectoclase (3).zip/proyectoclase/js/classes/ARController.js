class ARController {
    constructor() {
        this.isActive = false;
        this.video = null;
        this.canvas = null;
        this.ctx = null;
        this.arMarkers = [];
        this.currentPlanet = null;
        this.onARReadyCallback = null;
    }

    async initialize() {
        if (this.isActive) {
            console.log('AR ya está activo');
            return;
        }

        try {
            // Obtener elementos
            this.video = document.getElementById('arVideo');
            this.canvas = document.getElementById('arCanvas');
            this.ctx = this.canvas.getContext('2d');

            // Solicitar acceso a cámara trasera
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { 
                    facingMode: 'environment',
                    width: { ideal: 1280 },
                    height: { ideal: 720 }
                }
            });

            this.video.srcObject = stream;
            await this.video.play();

            // Ajustar tamaño del canvas
            this.canvas.width = this.video.videoWidth;
            this.canvas.height = this.video.videoHeight;

            // Iniciar detección de marcadores
            this.startARDetection();

            this.isActive = true;
            this.updateUI(true);
            console.log('📱 Modo AR activado');

            // Mostrar contenedor AR
            document.getElementById('arContainer').classList.remove('hidden');
            document.getElementById('scene3D').style.display = 'none';

        } catch (error) {
            console.error('Error al iniciar AR:', error);
            alert('No se pudo acceder a la cámara. Asegúrate de estar en HTTPS y permitir el acceso.');
        }
    }

    startARDetection() {
        const detect = () => {
            if (!this.isActive) return;

            // Dibujar frame de video
            this.ctx.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);

            // Detectar marcadores (simulación simple usando detección de color)
            this.detectMarkers();

            // Renderizar objetos 3D sobre marcadores
            this.renderARObjects();

            requestAnimationFrame(detect);
        };

        detect();
    }

    detectMarkers() {
        // Simulación de detección de marcadores
        // En producción se usaría AR.js, ARToolKit o similar
        
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const data = imageData.data;

        // Buscar regiones con colores específicos que actúen como marcadores
        this.arMarkers = [];

        // Dividir imagen en cuadrantes y buscar colores dominantes
        const gridSize = 4;
        const cellWidth = this.canvas.width / gridSize;
        const cellHeight = this.canvas.height / gridSize;

        for (let row = 0; row < gridSize; row++) {
            for (let col = 0; col < gridSize; col++) {
                const x = col * cellWidth;
                const y = row * cellHeight;
                
                const centerX = x + cellWidth / 2;
                const centerY = y + cellHeight / 2;
                
                const pixelIndex = (Math.floor(centerY) * this.canvas.width + Math.floor(centerX)) * 4;
                const r = data[pixelIndex];
                const g = data[pixelIndex + 1];
                const b = data[pixelIndex + 2];

                // Detectar si hay un color "marcador" (por ejemplo, rojo brillante)
                if (r > 200 && g < 100 && b < 100) {
                    this.arMarkers.push({
                        x: centerX,
                        y: centerY,
                        type: 'red_marker'
                    });
                }
            }
        }
    }

    renderARObjects() {
        if (!this.currentPlanet) return;

        // Dibujar planeta 3D sobre cada marcador detectado
        this.arMarkers.forEach(marker => {
            this.drawPlanetAt(marker.x, marker.y, this.currentPlanet);
        });

        // Si no hay marcadores, mostrar instrucciones
        if (this.arMarkers.length === 0) {
            this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
            this.ctx.fillRect(10, 10, 400, 80);
            this.ctx.fillStyle = '#ffffff';
            this.ctx.font = '20px Arial';
            this.ctx.fillText('🔍 Apunta a un objeto rojo para ver el planeta', 20, 40);
            this.ctx.fillText('O simplemente mueve la cámara', 20, 70);
        } else {
            // Mostrar cantidad de marcadores detectados
            this.ctx.fillStyle = 'rgba(0, 255, 0, 0.7)';
            this.ctx.fillRect(10, 10, 300, 40);
            this.ctx.fillStyle = '#000000';
            this.ctx.font = '18px Arial';
            this.ctx.fillText(`✅ ${this.arMarkers.length} marcador(es) detectado(s)`, 20, 35);
        }
    }

    drawPlanetAt(x, y, planetData) {
        const size = 80 * planetData.size;
        
        // Dibujar sombra
        this.ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        this.ctx.shadowBlur = 20;
        this.ctx.shadowOffsetX = 10;
        this.ctx.shadowOffsetY = 10;

        // Dibujar planeta
        const gradient = this.ctx.createRadialGradient(x - 20, y - 20, 0, x, y, size);
        gradient.addColorStop(0, this.colorToHex(planetData.color, 1.5));
        gradient.addColorStop(1, this.colorToHex(planetData.color, 0.5));
        
        this.ctx.fillStyle = gradient;
        this.ctx.beginPath();
        this.ctx.arc(x, y, size, 0, Math.PI * 2);
        this.ctx.fill();

        // Reset shadow
        this.ctx.shadowColor = 'transparent';

        // Dibujar información del planeta
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
        this.ctx.fillRect(x - 100, y + size + 10, 200, 60);
        
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = 'bold 20px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`${planetData.emoji} ${planetData.name}`, x, y + size + 35);
        
        this.ctx.font = '14px Arial';
        this.ctx.fillText(`Ø ${planetData.diameter}`, x, y + size + 55);

        this.ctx.textAlign = 'left'; // Reset
    }

    colorToHex(color, brightness = 1) {
        const r = Math.min(255, Math.floor(((color >> 16) & 255) * brightness));
        const g = Math.min(255, Math.floor(((color >> 8) & 255) * brightness));
        const b = Math.min(255, Math.floor((color & 255) * brightness));
        return `rgb(${r}, ${g}, ${b})`;
    }

    setPlanet(planetData) {
        this.currentPlanet = planetData;
        console.log('📱 Planeta AR configurado:', planetData.name);
    }

    stop() {
        this.isActive = false;

        if (this.video && this.video.srcObject) {
            const tracks = this.video.srcObject.getTracks();
            tracks.forEach(track => track.stop());
        }

        // Ocultar contenedor AR
        document.getElementById('arContainer').classList.add('hidden');
        document.getElementById('scene3D').style.display = 'block';

        this.updateUI(false);
        console.log('📱 Modo AR desactivado');
    }

    toggle() {
        if (this.isActive) {
            this.stop();
        } else {
            this.initialize();
        }
    }

    updateUI(active) {
        const status = document.getElementById('arStatus');
        const button = document.getElementById('toggleAR');

        if (active) {
            status.classList.add('active');
            status.querySelector('.text').textContent = 'AR: ON';
            button.classList.add('active');
            button.innerHTML = '<span class="icon">📱</span> Desactivar AR';
        } else {
            status.classList.remove('active');
            status.querySelector('.text').textContent = 'AR: OFF';
            button.classList.remove('active');
            button.innerHTML = '<span class="icon">📱</span> Activar AR';
        }
    }

    setOnARReady(callback) {
        this.onARReadyCallback = callback;
    }
}