// ==================== APLICACIÓN PRINCIPAL ====================

class EduARtApp {
    constructor() {
        this.voiceController = null;
        this.gestureController = null;
        this.arController = null;
        this.sceneController = null;
        this.currentPlanet = 'earth';
        
        this.init();
    }

    init() {
        console.log('🚀 Iniciando EduARt Pro...');

        try {
            // Inicializar controladores
            this.sceneController = new SceneController('canvas3D');
            this.voiceController = new VoiceController();
            this.gestureController = new GestureController('gestureCanvas');
            this.arController = new ARController();

            // Configurar callbacks
            this.setupCallbacks();

            // Configurar event listeners
            this.setupEventListeners();

            // Cargar planeta inicial
            this.loadPlanet('earth');

            console.log('✅ EduARt Pro iniciado correctamente');

        } catch (error) {
            console.error('❌ Error al iniciar:', error);
            alert('Error al iniciar la aplicación: ' + error.message);
        }
    }

    setupCallbacks() {
        // Voice commands
        this.voiceController.setOnCommand((command) => this.handleCommand(command));

        // Gesture commands
        this.gestureController.setOnGesture((gesture) => this.handleGesture(gesture));

        // AR ready
        this.arController.setOnARReady(() => {
            const planetData = PlanetData.getPlanet(this.currentPlanet);
            this.arController.setPlanet(planetData);
        });
    }

    setupEventListeners() {
        // Modal - ARREGLO PRINCIPAL
        const closeModalBtn = document.getElementById('closeModal');
        const modal = document.getElementById('instructionsModal');
        
        if (closeModalBtn) {
            closeModalBtn.addEventListener('click', () => {
                console.log('Cerrando modal...');
                if (modal) {
                    modal.classList.remove('active');
                }
            });
        }

        // Voice control
        const toggleVoiceBtn = document.getElementById('toggleVoice');
        if (toggleVoiceBtn) {
            toggleVoiceBtn.addEventListener('click', () => {
                this.voiceController.toggle();
            });
        }

        const voiceLangSelect = document.getElementById('voiceLanguage');
        if (voiceLangSelect) {
            voiceLangSelect.addEventListener('change', (e) => {
                this.voiceController.setLanguage(e.target.value);
            });
        }

        // Gesture control
        const toggleGesturesBtn = document.getElementById('toggleGestures');
        if (toggleGesturesBtn) {
            toggleGesturesBtn.addEventListener('click', () => {
                this.gestureController.toggle();
            });
        }

        // AR control
        const toggleARBtn = document.getElementById('toggleAR');
        if (toggleARBtn) {
            toggleARBtn.addEventListener('click', () => {
                this.arController.toggle();
                if (this.arController.isActive) {
                    const planetData = PlanetData.getPlanet(this.currentPlanet);
                    this.arController.setPlanet(planetData);
                }
            });
        }

        // Planet selection
        const planetSelect = document.getElementById('planetSelect');
        if (planetSelect) {
            planetSelect.addEventListener('change', (e) => {
                this.currentPlanet = e.target.value;
            });
        }

        const loadPlanetBtn = document.getElementById('loadPlanet');
        if (loadPlanetBtn) {
            loadPlanetBtn.addEventListener('click', () => {
                this.loadPlanet(this.currentPlanet);
            });
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            switch(e.key.toLowerCase()) {
                case 'v':
                    this.voiceController.toggle();
                    break;
                case 'g':
                    this.gestureController.toggle();
                    break;
                case 'a':
                    this.arController.toggle();
                    if (this.arController.isActive) {
                        const planetData = PlanetData.getPlanet(this.currentPlanet);
                        this.arController.setPlanet(planetData);
                    }
                    break;
                case '+':
                case '=':
                    e.preventDefault();
                    this.sceneController.zoomIn();
                    break;
                case '-':
                case '_':
                    e.preventDefault();
                    this.sceneController.zoomOut();
                    break;
                case 'r':
                    this.sceneController.toggleRotation();
                    break;
                case 'arrowleft':
                    e.preventDefault();
                    this.sceneController.rotateLeft();
                    break;
                case 'arrowright':
                    e.preventDefault();
                    this.sceneController.rotateRight();
                    break;
                case 'i':
                    this.speakPlanetInfo();
                    break;
                case '1':
                    this.loadPlanet('mercury');
                    break;
                case '2':
                    this.loadPlanet('venus');
                    break;
                case '3':
                    this.loadPlanet('earth');
                    break;
                case '4':
                    this.loadPlanet('mars');
                    break;
                case '5':
                    this.loadPlanet('jupiter');
                    break;
                case '6':
                    this.loadPlanet('saturn');
                    break;
                case '7':
                    this.loadPlanet('uranus');
                    break;
                case '8':
                    this.loadPlanet('neptune');
                    break;
                case 'escape':
                    // Cerrar modal con ESC
                    if (modal && modal.classList.contains('active')) {
                        modal.classList.remove('active');
                    }
                    break;
            }
        });

        // Sidebar toggle for mobile
        if (window.innerWidth <= 1024) {
            const hamburger = document.createElement('button');
            hamburger.innerHTML = '☰';
            hamburger.className = 'hamburger-btn';
            hamburger.style.cssText = 'position: fixed; top: 80px; left: 10px; z-index: 200; background: var(--color-primary); color: white; border: none; padding: 10px 15px; border-radius: 8px; cursor: pointer; font-size: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);';
            hamburger.addEventListener('click', () => {
                const sidebar = document.querySelector('.sidebar');
                if (sidebar) {
                    sidebar.classList.toggle('open');
                }
            });
            document.body.appendChild(hamburger);
        }
    }

    handleCommand(command) {
        console.log('📢 Comando recibido:', command);

        // Planet commands
        const planets = ['mercury', 'venus', 'earth', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune'];
        if (planets.includes(command)) {
            this.loadPlanet(command);
            return;
        }

        // Action commands
        switch(command) {
            case 'zoom_in':
            case 'acercar':
                this.sceneController.zoomIn();
                this.showNotification('🔍 Acercando vista');
                break;
            case 'zoom_out':
            case 'alejar':
                this.sceneController.zoomOut();
                this.showNotification('🔍 Alejando vista');
                break;
            case 'rotate':
            case 'rotar':
                this.sceneController.toggleRotation();
                this.showNotification('🔄 Rotación alternada');
                break;
            case 'pause':
            case 'pausar':
                this.sceneController.toggleRotation();
                this.showNotification('⏸️ Pausa alternada');
                break;
            case 'info':
            case 'información':
                this.speakPlanetInfo();
                break;
            case 'ar':
                this.arController.toggle();
                if (this.arController.isActive) {
                    const planetData = PlanetData.getPlanet(this.currentPlanet);
                    this.arController.setPlanet(planetData);
                    this.showNotification('📱 Modo AR activado');
                } else {
                    this.showNotification('📱 Modo AR desactivado');
                }
                break;
            default:
                this.showNotification('❓ Comando no reconocido');
                break;
        }
    }

    handleGesture(gesture) {
        console.log('✋ Gesto detectado:', gesture);

        switch(gesture) {
            case 'zoom_in':
                this.sceneController.zoomIn();
                break;
            case 'zoom_out':
                this.sceneController.zoomOut();
                break;
            case 'rotate_left':
                this.sceneController.rotateLeft();
                break;
            case 'rotate_right':
                this.sceneController.rotateRight();
                break;
            case 'pause':
                this.sceneController.toggleRotation();
                break;
            case 'select':
                this.speakPlanetInfo();
                break;
        }
    }

    loadPlanet(planetKey) {
        this.currentPlanet = planetKey;
        this.sceneController.loadPlanet(planetKey);
        
        // Update select
        const select = document.getElementById('planetSelect');
        if (select) {
            select.value = planetKey;
        }

        // Update AR if active
        if (this.arController.isActive) {
            const planetData = PlanetData.getPlanet(planetKey);
            this.arController.setPlanet(planetData);
        }

        // Speak planet name
        const planetData = PlanetData.getPlanet(planetKey);
        this.voiceController.speak(`Mostrando ${planetData.name}`);
        this.showNotification(`🪐 ${planetData.emoji} ${planetData.name} cargado`);
    }

    speakPlanetInfo() {
        const planetData = PlanetData.getPlanet(this.currentPlanet);
        const info = `${planetData.name}. ${planetData.description}. Diámetro: ${planetData.diameter}. Distancia al Sol: ${planetData.distance}.`;
        this.voiceController.speak(info);
        this.showNotification(`ℹ️ Información de ${planetData.name}`);
    }

    showNotification(message) {
        let notification = document.getElementById('app-notification');
        
        if (!notification) {
            notification = document.createElement('div');
            notification.id = 'app-notification';
            notification.style.cssText = `
                position: fixed;
                top: 80px;
                right: 20px;
                background: rgba(26, 34, 51, 0.95);
                color: white;
                padding: 15px 20px;
                border-radius: 12px;
                border: 1px solid var(--color-border);
                backdrop-filter: blur(10px);
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
                z-index: 1000;
                font-size: 0.95rem;
                min-width: 250px;
                opacity: 0;
                transform: translateY(-20px);
                transition: all 0.3s ease;
                pointer-events: none;
            `;
            document.body.appendChild(notification);
        }

        notification.textContent = message;
        notification.style.opacity = '1';
        notification.style.transform = 'translateY(0)';

        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateY(-20px)';
        }, 3000);
    }

    dispose() {
        if (this.voiceController) {
            this.voiceController.stop();
        }
        if (this.gestureController) {
            this.gestureController.stop();
        }
        if (this.arController) {
            this.arController.stop();
        }
        if (this.sceneController) {
            this.sceneController.dispose();
        }
    }
}

// ==================== INICIAR APLICACIÓN ====================
let app;

window.addEventListener('DOMContentLoaded', () => {
    console.log('📄 DOM cargado, iniciando aplicación...');
    
    try {
        app = new EduARtApp();
        
        console.log(`
╔═══════════════════════════════════════════════════════════╗
║   🚀 EduARt Pro - Explorador Solar Interactivo          ║
║                                                           ║
║   ✅ Sistema iniciado correctamente                      ║
║                                                           ║
║   📝 Atajos de teclado:                                 ║
║      V - Toggle Voz                                      ║
║      G - Toggle Gestos                                   ║
║      A - Toggle AR                                       ║
║      R - Rotación automática                            ║
║      I - Información del planeta                        ║
║      +/- - Zoom                                          ║
║      ←/→ - Rotar vista                                  ║
║      1-8 - Cargar planetas                              ║
║      ESC - Cerrar modal                                  ║
╚═══════════════════════════════════════════════════════════╝
        `);

    } catch (error) {
        console.error('❌ Error al iniciar la aplicación:', error);
        alert('Error al iniciar EduARt Pro: ' + error.message + '\n\nPor favor, verifica que todos los archivos JS estén en su lugar.');
    }
});

// ==================== ERROR HANDLING ====================
window.addEventListener('error', (e) => {
    console.error('❌ Error global:', e.message);
    console.error('Archivo:', e.filename);
    console.error('Línea:', e.lineno, 'Columna:', e.colno);
});

window.addEventListener('unhandledrejection', (e) => {
    console.error('❌ Promise rechazada:', e.reason);
});

// ==================== CLEANUP ====================
window.addEventListener('beforeunload', () => {
    if (app) {
        app.dispose();
    }
});